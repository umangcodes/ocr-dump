import Portal from "./Portal"

const UploadPrompt = () => {
  return (
    <Portal>
      <div className="relative flex w-full h-full bg-black/40">
        <div className="absolute w-full h-[256px] bg-white">

        </div>
      </div>
    </Portal>
  )
}

export default UploadPrompt